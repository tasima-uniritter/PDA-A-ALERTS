package br.com.unirriter.bobsin.bobsin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BobsinApplication {

	public static void main(String[] args) {
		SpringApplication.run(BobsinApplication.class, args);
	}
}
